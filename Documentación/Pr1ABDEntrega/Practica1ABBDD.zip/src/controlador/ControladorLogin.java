package controlador;

import javax.sql.DataSource;

import vista.VistaLog;
import mappers.UsuariosMapper;
import modelo.BBDD;

public class ControladorLogin {

	private VistaLog vista;
	private DataSource ds;
	private UsuariosMapper userMapper;
	
	public ControladorLogin(VistaLog vista){
		this.vista = vista;
		this.ds = new BBDD().getDataSource();
		this.userMapper = new UsuariosMapper(this.ds);
		vista.addLoginListener(new ListenerLogin(vista, userMapper));
		
	}

}
