package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import mappers.UsuariosMapper;
import modelo.Usuario;
import vista.VistaLog;

public class ListenerLogin implements ActionListener{

	private VistaLog vista;
	UsuariosMapper userMapper;
	
	public ListenerLogin(VistaLog vista, UsuariosMapper userMapper){
		super();
		this.vista = vista;
		this.userMapper = userMapper;
	}
	
	public void actionPerformed(ActionEvent e) {
		String nick;
		nick = vista.getUsuarioText();
		if(!nick.equals("")){
			Usuario user = userMapper.findById(nick);
			if(user!=null && user.getPassword().equals(vista.getPasswordText())){
				vista.setVisible(false);
				vista.cerrar();
				vista.loginSuccess();
			}
		}
		
	}
}
