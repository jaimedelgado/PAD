package modelo;

import java.sql.Date;

public class Serie {
	
	private int idSerie;
	private String nombre;
	private String titular;
	private String sinopsis;
	private Date estreno;
	
	public Serie(int idSerie, String nombre, String titular, String sinopsis,
			Date estreno) {
		this.idSerie = idSerie;
		this.nombre = nombre;
		this.titular = titular;
		this.sinopsis = sinopsis;
		this.estreno = estreno;
	}
	
	public int getIdSerie() {
		return idSerie;
	}
	public void setIdSerie(int idSerie) {
		this.idSerie = idSerie;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getTitular() {
		return titular;
	}
	public void setTitular(String titular) {
		this.titular = titular;
	}
	public String getSinopsis() {
		return sinopsis;
	}
	public void setSinopsis(String sinopsis) {
		this.sinopsis = sinopsis;
	}
	public Date getEstreno() {
		return estreno;
	}
	public void setEstreno(Date estreno) {
		this.estreno = estreno;
	}

}
