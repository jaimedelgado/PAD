package modelo;

import java.sql.Date;

public class Usuario {
	
	private String nick;
	private String password;
	private Date nacimiento;
	private byte[] imagen;
	
	public Usuario(String nick, String password, Date nacimiento) {
		this.nick = nick;
		this.password = password;
		this.nacimiento = nacimiento;
		this.imagen = null;
	}
	
	public String getNick() {
		return nick;
	}
	public void setNick(String nick) {
		this.nick = nick;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Date getNacimiento() {
		return nacimiento;
	}
	public void setNacimiento(Date nacimiento) {
		this.nacimiento = nacimiento;
	}
	public byte[] getImagen() {
		return imagen;
	}
	public void setImagen(byte[] imagen) {
		this.imagen = imagen;
	}
	
	

}
