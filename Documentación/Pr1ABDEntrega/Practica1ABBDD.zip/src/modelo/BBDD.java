package modelo;

import java.beans.PropertyVetoException;

import javax.sql.DataSource;

import com.mchange.v2.c3p0.ComboPooledDataSource;

public class BBDD {

	private ComboPooledDataSource cpds;
	private DataSource ds;
	
	public BBDD(){
	cpds = new ComboPooledDataSource();
	
	try {
		cpds.setDriverClass("org.gjt.mm.mysql.Driver");
		cpds.setJdbcUrl("jdbc:mysql://localhost/Práctica1");
		cpds.setUser("root");
		cpds.setPassword("");
		cpds.setAcquireRetryAttempts(1);
		cpds.setAcquireRetryDelay(1);
		cpds.setBreakAfterAcquireFailure(true);
	} catch (PropertyVetoException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	this.ds = cpds;
	}
	
	public DataSource getDataSource(){
		return this.ds;
	}
	
	
}
