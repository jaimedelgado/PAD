package vista;

public class VistaNuevoUsuario {

}
