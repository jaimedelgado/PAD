package mappers;

import java.beans.PropertyVetoException;

import javax.sql.DataSource;
import javax.swing.JOptionPane;

import vista.VistaLog;

import com.mchange.v2.c3p0.ComboPooledDataSource;

import controlador.ControladorLogin;
import modelo.Usuario;

public class Main {

	public static void main(String[] args) {
		
		VistaLog vista = new VistaLog();
		ControladorLogin controlador = new ControladorLogin(vista);
		
	/*	ComboPooledDataSource cpds = new ComboPooledDataSource();
		
		try {
			cpds.setDriverClass("org.gjt.mm.mysql.Driver");
			cpds.setJdbcUrl("jdbc:mysql://localhost/Práctica1");
			cpds.setUser("root");
			cpds.setPassword("");
			cpds.setAcquireRetryAttempts(1);
			cpds.setAcquireRetryDelay(1);
			cpds.setBreakAfterAcquireFailure(true);
		} catch (PropertyVetoException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		DataSource ds = cpds;
		
		VistaLog vista = new VistaLog();

		UsuariosMapper mapper = new UsuariosMapper(ds);*/
		
		//String id = JOptionPane.showInputDialog("Introduzca un nick: ");
		
		
		//Usuario user = mapper.findById(id);
		
		//JOptionPane.showMessageDialog(null,  user.getPassword(), " " + "", JOptionPane.INFORMATION_MESSAGE);
				
	}

}
