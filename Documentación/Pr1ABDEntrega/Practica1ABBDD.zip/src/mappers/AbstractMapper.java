package mappers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.apache.commons.lang3.StringUtils;

public abstract class AbstractMapper<T,K> {

	protected DataSource ds;

	protected abstract String getTableName();

	protected abstract String[] getColumnNames();

	protected abstract T buildObject(ResultSet rs) throws SQLException;

	protected abstract String getKeyColumnName();

	public AbstractMapper(DataSource ds) {
		this.ds = ds;
	}

	public T findById(K id) {
		Connection con        = null;
		PreparedStatement pst = null;
		ResultSet rs          = null;
		T result       = null;
		try {
			con = ds.getConnection();
			String[] columnNames = getColumnNames();
			String columnNamesWithCommas = StringUtils.join(columnNames, ", ");
			pst = con.prepareStatement(
					"SELECT " + columnNamesWithCommas + " FROM " + getTableName() +  
					" WHERE " + getKeyColumnName() + " = ?"
					);
			pst.setObject(1, id);
			rs = pst.executeQuery();
			if (rs.next()) {
				result = buildObject(rs);
			} 
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null) rs.close();
				if (pst != null) pst.close();
				if (con != null) con.close();
			} catch (Exception e) {}
		}
		return result;
	}
	
	public T insert(K id) {
		Connection con        = null;
		PreparedStatement pst = null;
		ResultSet rs          = null;
		T result       = null;
		try {
			con = ds.getConnection();
			String[] columnNames = getColumnNames();
			String columnNamesWithCommas = StringUtils.join(columnNames, ", ");
			pst = con.prepareStatement(
					"SELECT " + columnNamesWithCommas + " FROM " + getTableName() +  
					" WHERE " + getKeyColumnName() + " = ?"
					);
			pst.setObject(1, id);
			rs = pst.executeQuery();
			if (rs.next()) {
				result = buildObject(rs);
			} 
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null) rs.close();
				if (pst != null) pst.close();
				if (con != null) con.close();
			} catch (Exception e) {}
		}
		return result;
	}

}