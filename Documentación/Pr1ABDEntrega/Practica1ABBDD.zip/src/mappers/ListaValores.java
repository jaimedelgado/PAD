package mappers;

import java.util.List;

public class ListaValores {
	private List<String> lista;
	
	public ListaValores(){
	}
	
}
