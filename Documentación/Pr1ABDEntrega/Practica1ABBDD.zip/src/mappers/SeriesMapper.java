package mappers;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import modelo.Serie;

public class SeriesMapper extends AbstractMapper<Serie, Integer>{

	private static final String SERIES_KEY_COLUMN_NAME = "IdSerie";
	private static final String[] SERIES_COLUMN_NAMES = new String[]{
		SERIES_KEY_COLUMN_NAME,
		"Nombre", 
		"Titular", 
		"Sinopsis", 
		"Estreno", 
		"Finalizacion"};
	private static final String SERIES_TABLE_NAME = "Series";
	
	public SeriesMapper(DataSource ds) {
		super(ds);
	}
	protected Serie buildObject(ResultSet rs) throws SQLException {
		Serie result;
		int idSerie = rs.getInt(SERIES_KEY_COLUMN_NAME);
		String nombre = rs.getString("Nombre");
		String titular = rs.getString("Titular");
		String sinopsis = rs.getString("Sinopsis");
		Date estreno = rs.getDate("Estreno");
		
		result = new Serie(idSerie, nombre, titular, sinopsis, estreno);
		
		return result;
	}
	protected String getTableName() {
		return SERIES_TABLE_NAME;
	}
	protected String[] getColumnNames() {
		return SERIES_COLUMN_NAMES;
	}
	protected String getKeyColumnName() {
		return SERIES_KEY_COLUMN_NAME;
	}

}
